package AutomationFramework.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utils.Utils;

public class LandingPage extends Utils{
	WebDriver driver;
	
	/*
	 * Creating consstructor for initializing driver
	 */

	public LandingPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
//	WebElement userEmail = driver.findElement(By.id("userEmail"));
//	WebElement userPassword= driver.findElement(By.id("userPassword")); 
//	WebElement loginBtn = driver.findElement(By.id("login"));

/*
 * Page Factory declaration of locators
 */
	@FindBy(id="userEmail")
	WebElement userEmail;
	
	@FindBy(id= "userPassword")
	WebElement userPassword;
	
	@FindBy(id="login")
	WebElement loginBtn;
	
	@FindBy(css="[class*='flyInOut']")
	WebElement errorMessage;

	
	public ProductCatalogPage loginApplication(String email, String password) {
		userEmail.sendKeys(email);
		userPassword.sendKeys(password);
		loginBtn.click();
		ProductCatalogPage productcatalogpage = new ProductCatalogPage(driver);
		return productcatalogpage;
	}

	public String getErrorMessage() {
		waitForWebElementToAppear(errorMessage);
		return errorMessage.getText();
		
	}
	
	public void goToURL() {
		driver.get("https://rahulshettyacademy.com/client/");
	}
	
	
	
	
	
	
	
	
}
