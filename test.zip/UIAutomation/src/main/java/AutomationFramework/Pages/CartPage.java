package AutomationFramework.Pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utils.Utils;

public class CartPage extends Utils {

	WebDriver driver;

	public CartPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@class='cartSection']/h3")
	List<WebElement> cartProducts;
	
	@FindBy(xpath = "//button[text()='Checkout']")
	WebElement checkoutBtn;

	public boolean verifyProductName(String nameOfProduct) {
		boolean match = cartProducts.stream()
				.anyMatch(cartProduct -> cartProduct.getText().equalsIgnoreCase(nameOfProduct));
		return match;
	}

//	driver.findElement(By.cssSelector(".totalRow button")).click();

	public CheckOutPage clickOnCheckOutBtn() {
		checkoutBtn.click();
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		System.out.println("Checkoutpage returned: "+ checkoutpage);
		return checkoutpage;
	}

}
