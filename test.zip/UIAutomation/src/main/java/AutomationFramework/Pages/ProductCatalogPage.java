package AutomationFramework.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utils.Utils;

public class ProductCatalogPage extends Utils {

	WebDriver driver;
	
	public ProductCatalogPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	

//	List<WebElement> products = driver.findElements(By.cssSelector(".mb-3"));
	@FindBy (css=".mb-3")
	List <WebElement> products;
	
	@FindBy(css = ".ng-animating")
	WebElement loadingIndicator;
	
	@FindBy(css="[routerlink*='cart']")
	WebElement cartBtn;
	
	

	By productsBy= By.cssSelector(".mb-3");
	By addToCart = (By.xpath("//button[@style='float: right;']"));
	By toastMsgBy = By.id("toast-container");
	
	
	
	public List<WebElement> getProductList() {
//wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".mb-3")));		
	
		waitForElementToAppear(productsBy);
		return products;
	}
	
	public WebElement getProductByName(String productName) {
		
		WebElement prod = getProductList().stream()
				.filter(product -> product.findElement(By.xpath("//h5/b")).getText().equals(productName)).findFirst()
				.orElse(null);
	
		
		return prod;
	}
	
	
	public void addProductToCart(String productName) {
		
		WebElement prod= getProductByName(productName);
		prod.findElement(addToCart).click();
		waitForElementToAppear(toastMsgBy);
		waitForElementToDisappear(loadingIndicator);
		
	}
	
	
	
	
}
