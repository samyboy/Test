package AutomationFramework.UIAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import AutomationFramework.Pages.CartPage;
import AutomationFramework.Pages.CheckOutPage;
import AutomationFramework.Pages.ConfirmationPage;
import AutomationFramework.Pages.OrdersPage;
import AutomationFramework.Pages.ProductCatalogPage;

public class SubmitOrderTest extends BaseTest {
	String productName = "ADIDAS ORIGINAL";
	
	@Test (dataProvider="getData", groups= {"Purchase"})
	public void submitOrder(HashMap <String, String>input) throws IOException, InterruptedException {

	
//		ProductCatalogPage productcatalogpage = landingpage.loginApplication("tam@gmail.com", "Sameer@1986");
		ProductCatalogPage productcatalogpage = landingpage.loginApplication(input.get("email"), input.get("password"));
		List<WebElement> products = productcatalogpage.getProductList();

//		productcatalogpage.addProductToCart(nameOfProduct);
		productcatalogpage.addProductToCart(input.get("product"));
		CartPage cartpage = productcatalogpage.clickOnCartHeaderMenu();

		boolean match = cartpage.verifyProductName(input.get("product"));
		Assert.assertTrue(match);
		CheckOutPage checkoutpage = cartpage.clickOnCheckOutBtn();
		checkoutpage.selectCountry("India");
		ConfirmationPage confirmationpage = checkoutpage.submitOrder();

		String confirmMsg = confirmationpage.getConfirmationMessage();
		System.out.println("Msg: " + confirmMsg);
		Assert.assertTrue(confirmMsg.equalsIgnoreCase("THANKYOU FOR THE ORDER."));

	}

	/*
	 * To verify the added product is present in Orders page
	 */

	@Test(dependsOnMethods = {"submitOrder"})
	public void orderHistoryTest() {

		ProductCatalogPage productcatalogpage = landingpage.loginApplication("anshika@gmail.com", "Iamking@000");
		OrdersPage orderspage = productcatalogpage.clickOnOrdersHeaderMenu();
	//	boolean match = orderspage.verifyOrderDisplay(nameOfProduct);
//		System.out.println(orderspage.verifyOrderDisplay(nameOfProduct));
		Assert.assertTrue(orderspage.verifyOrderDisplay(productName));
	
	}
	
	@DataProvider
	public Object[][] getData() throws IOException {
		
		HashMap <String, String> map = new HashMap();
		map.put("email", "tam@gmail.com");
		map.put("password", "Sameer@1986");
		map.put("product", "ZARA COAT 3");
		
		HashMap <String, String> map1 = new HashMap();
		map1.put("email", "shetty@gmail.com");
		map1.put("password", "Iamking@000");
		map1.put("product", "ADIDAS ORIGINAL");
//		List<HashMap<String, String>> data = getJSONDataToMap(System.getProperty("user.dir") + "\\src\\main\\java\\Data\\PurchaseOrder.json");
		return new Object[][] {{map},{map1}};
	}
	
}
