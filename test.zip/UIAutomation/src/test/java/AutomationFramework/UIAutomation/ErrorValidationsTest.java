package AutomationFramework.UIAutomation;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import AutomationFramework.Pages.CartPage;
import AutomationFramework.Pages.CheckOutPage;
import AutomationFramework.Pages.ConfirmationPage;
import AutomationFramework.Pages.ProductCatalogPage;

public class ErrorValidationsTest extends BaseTest {
	
	@Test
	public void zloginErrorValidation() throws IOException {

		String nameOfProduct = "ZARA COAT 3";
		ProductCatalogPage productcatalogpage = landingpage.loginApplication("tam@gmail.com", "Same@1986");
		landingpage.getErrorMessage();
		Assert.assertEquals("Incorrect email or password.",landingpage.getErrorMessage());

	}
	
	@Test
	public void productErrorValidation() throws IOException {

		String nameOfProduct = "ZARA COAT 3";
		ProductCatalogPage productcatalogpage = landingpage.loginApplication("anshika@gmail.com", "Iamking@000");
		List<WebElement> products = productcatalogpage.getProductList();
		productcatalogpage.addProductToCart(nameOfProduct);
		CartPage cartpage = productcatalogpage.clickOnCartHeaderMenu();
		boolean match = cartpage.verifyProductName("ZARA COAT 35");
		Assert.assertFalse(match);
		
	}
	

	

}
